<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since 0.2
 */

/**
 * Error 403
 */
class EActiveResourceRequestException_BadRequest extends EActiveResourceException{}

?>
