<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since version 0.1
 */

/**
 * A custom Exception for ActiveResource
 */
class EActiveResourceException extends CException{}
