<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since 0.2
 */

/**
 * Error 406
 */
class EActiveResourceRequestException_NotAcceptable extends EActiveResourceRequestException{}

?>
