<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since 0.2
 */

/**
 * Error 404
 */
class EActiveResourceRequestException_NotFound extends EActiveResourceRequestException{}

?>
