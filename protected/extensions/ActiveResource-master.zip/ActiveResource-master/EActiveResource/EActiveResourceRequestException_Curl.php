<?php
class EActiveResourceRequestException_Curl extends CException {}
?>
