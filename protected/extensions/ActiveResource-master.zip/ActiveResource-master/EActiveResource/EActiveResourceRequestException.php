<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since 0.2
 */

class EActiveResourceRequestException extends EActiveResourceException{}
?>
