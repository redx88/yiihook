<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since 0.2
 */

/**
 * Error 401
 */
class EActiveResourceRequestException_UnauthorizedAccess extends EActiveResourceRequestException{}

?>
