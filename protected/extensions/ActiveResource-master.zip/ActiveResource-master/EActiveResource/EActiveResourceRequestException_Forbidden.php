<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since 0.2
 */

/**
 * Error 402
 */
class EActiveResourceRequestException_Forbidden extends EActiveResourceRequestException{}

?>
