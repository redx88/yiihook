<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since 0.2
 */

/**
 * Error 405
 */
class EActiveResourceRequestException_MethodNotAllowed extends EActiveResourceRequestException{}

?>
