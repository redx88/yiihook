<?php
/**
 * @author Johannes "Haensel" Bauer
 * @since 0.2
 */

/**
 * Error 407
 */
class EActiveResourceRequestException_ProxyAuthentication extends EActiveResourceRequestException{}

?>
