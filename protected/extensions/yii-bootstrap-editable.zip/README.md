Yii-Bootstrap-Editable
======================

This extension joins [Yii framework](http://yiiframework.com) with [Bootstrap Editable plugin](http://vitalets.github.com/bootstrap-editable) allowing in-place editing with [Twitter Bootstrap](http://twitter.github.com/bootstrap) Form and Popover.
Includes three widgets and one component that together give you extremely fast and easy way for creating editable interfaces. 

## Demo & Documentation

http://demopage.ru/yii-bootstrap-editable

## Contributing
Please make all pull requests against `dev` branch. Your feedback / contribution is very appreciated.

## Questions
If you have question please feel free to [create an issue](https://github.com/vitalets/yii-bootstrap-editable/issues).